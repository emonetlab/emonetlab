Extended contact map stencil for OmniGraffle (The Omni Group, Seattle, WA)

OmniGraffle is a commercial general-purpose drawing tool for the Mac platform.  A free trial is available (http://www.omnigroup.com/products/omnigraffle/).

This stencil provides a set of boxes, arrows, and miscellaneous other symbols commonly used in an extended contact map. These instructions are written for OmniGraffle Professional 5. 

To install: open "Contact Maps.stencil" in OmniGraffle and click "Install" in the stencil window. 


General instructions: 

To use a symbol, drag it from the stencil window to your canvas. 

Many symbols consist of grouped objects. An object within a group can be manipulated individually by first clicking on the group and then clicking on the object.

To ungroup objects, select the group and go to Arrange -> Ungroup. Use Arrange -> Group to group objects to your convenience. 

To edit text, double-click on a text label. 

To select multiple objects, use the "command" key, or drag your mouse across the objects you wish to select. 

To resize an object, select it and move the edges.

The "Rubber Stamp" tool provides a way to quickly duplicate an object. 

Layers are a useful way of organizing a map. Different elements of a map (e.g., a certain set of molecules, or the set of contextual arrows) can be placed on different layers. Layers can then be turned on or off to show or hide certain elements of a map. To create a new layer, go to Edit -> Layers -> New Layer. To view your layers, go to View -> Sidebars -> Canvases. Layers can be rearranged (objects on upper layers appear in front of objects on lower layers) and renamed. To turn a layer off, click on the eye icon that appears when your mouse hovers above a layer in the sidebar. 

OmniGraffle can export files into a number of useful formats other than .graffle, including PDF vector image (.pdf), EPS vector image (.eps), Visio XML (.vdx, used by Microsoft Visio), and Photoshop image (.psd). Some or all of these formats can be understood by other drawing programs. To export into one of these formats or any of the other formats supported by OmniGraffle, go to File -> Export and select the desired format. It also worth noting that .pdf files can be opened and modified in OmniGraffle. 

Maps can be made interactive. For example, when an object is clicked, a URL or file can open, a script can run, or a jump can be made to a different area of the canvas. To use these capabilities, go to Inspectors -> Properties, and click on the "Actions" tab. 

Boxes:

The first "Protein" consists of a molecule box, component and subcomponent boxes, and a location tag. Select components by clicking on them. Copy, paste, and delete as needed. 

The second "Protein" consists of a molecule box and overlapping components, which are distinguished with colors.

The third "Protein" consists of a dotted molecule box to indicate a divisible protein, and two components connected by a covalent bond. 

The first DNA box contains a single DNA component. 

The second DNA box contains two DNA components, Promoter and Gene. 


Flags:

The first four flags represent modification "m" of residue "R". Dots are placed on flags as termination points for arrows. The first and third flag are equivalent, as are the second and fourth. 

Lines in these flags are connected to text labels. Lines may be reshaped without having to move lines and text separately. 

Move flags into protein boxes. Group box and flag together. 


Background:

The background box contains three layers.
Resize the box by selecting it and manipulating the sides/corners.
Select the gray rectangle to resize it. Copy and paste the gray rectangle to create as many layers as needed. 


Arrows: 

Arrow styles are explained in Fig. 5. 

To reorient a line, select its endpoint and move the endpoint.

To bend a line, double click on a line to create a midpoint. Endpoints and midpoints can be moved independently of each other to reshape a line as desired. 

To connect an arrow to other lines or arrows, go to Inspectors -> Lines and Shapes. Under "Properties: Connections", select the connection options that you need. Connecting arrows directly to boxes/lines avoids the need to move objects separately; an object can be moved and all connections are maintained. However, disconnecting arrows from boxes may allow for more precision in arrangement of objects. 

Special note: the second arrow given here is a group of arrows that represent multiple catalysis events. These arrows may be manipulated individually by first clicking on the group and then clicking on individual arrows. These arrows may also be ungrouped.


Miscellaneous:

The "L" location tag may be attached to the lower left corner of molecule boxes. 

The "XOR" symbol is to be placed between component boxes. 

Branch points can be connected to arrows. 

A branch point can be reversed by selecting one of its edges and dragging it past the opposite edge.

A number of symbols to represent chemical reactions are provided. 
